const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const redis = require('redis');
const axios = require('axios');
const client = redis.createClient();
const bluebird = require('bluebird');
fetch.Promise = bluebird;

bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);


router.get('/', async (req, res, next) => {
    let cacheExists = await client.getAsync('showListHomepage');
    if (cacheExists) {
        console.log("list is already cached");
        res.status(200).send(cacheExists);
    } else {
        next();
    }
});

router.get('/', async (req, res) => {
        // fetch('http://api.tvmaze.com/shows')
        // .then(res => res.json())
        // .then(json => res.render('shows', {show: json}, function (err, html) {
        //     res.send(html);
        //     client.setAsync('showListHomepage', html)
        //     console.log("fetching from api and rendering html, show list is now cached")
        // }));

        try {
            let {data} = await axios.get('http://api.tvmaze.com/shows')
            res.render('shows', {show: data}, function (err, html) {
                res.status(200).send(html);
                client.setAsync('showListHomepage', html)
                console.log("fetching from api and rendering html, show list is now cached")
            })
        } catch (e) {
            console.log(e)
        }
    }

);

router.get('/show/:id', async (req, res, next) => {
    let cacheExists = await client.getAsync(req.params.id);
    if (cacheExists) {
        console.log("show page is cached");
        res.status(200).send(cacheExists)
    } else {
        next();
    }
});

router.get('/show/:id', async (req, res) => {
    // fetch('http://api.tvmaze.com/shows/' + req.params.id)
    // .then(res => res.json())
    // .then(json => res.render('showPage', {showInfo: json}, function (err, html) {
    //     if (json.name == "Not Found") {
    //         res.status(404)
    //         res.send("Show Not Found")
    //         return;
    //     }
    //     res.send(html);
    //     client.setAsync(req.params.id, html)
    //     console.log("fetching from api and rendering html, show page details are now cached")
    // }));

    try {
        let {data} = await axios.get('http://api.tvmaze.com/shows/' + req.params.id)
        let hasRating = true;
        if (data.rating.average == null) {
            hasRating = false;
        }
        let hasNetwork = true;
        if (data.network.name == null) {
            hasNetwork = false;
        }
        let hasGenre = true;
        if (data.genres.length == 0)
        {
            hasGenre = false;
        }
        res.render('showPage', {showInfo: data, hasRating: hasRating, hasNetwork: hasNetwork, hasGenre: hasGenre, notFound: false}, function (err, html) {
            res.send(html);
            res.status(200);
            client.setAsync(req.params.id, html)
            console.log("fetching from api and rendering html, show page list is now cached")
        })
    } catch (e) {
        console.log("Show Not Found")
        res.render('showPage', {notFound: true});
        res.status(404);
    }
});

router.post('/search', async (req, res, next) => {
    let trim = req.body.search.trim();
    let cacheExists = await client.getAsync("SEARCH_RESULT_" + trim);
    if (cacheExists) {
        client.ZINCRBY('search', 1, trim)
        console.log("search results already cached");
        res.status(200).send(cacheExists);
    } else {
        next();
    }
})

router.post('/search', async (req, res) => {
    let empty = false;
    let trim = req.body.search.trim();
    let error = false;
    if ((!req.body) || !trim) {
        error = true;
    }
    if (error == true) {
        res.render('showSearch', {error: error});
        res.status(400);
        return;
    }
    try {
        let {data} = await axios.get('http://api.tvmaze.com/search/shows?q=' + trim)
        if (data.length == 0) {
            empty = true;
        }
        res.render('showSearch', {show: data, error: error, empty: empty, search: trim}, function (err, html) {
        res.status(200).send(html);
        client.setAsync("SEARCH_RESULT_" + trim, html)
        client.ZADD("search", 1, trim)
        console.log("fetching from api and rendering html, search results page is now cached")
    })
    } catch (e) {
        console.log(e);
    }
})

router.get('/popularsearches', async (req, res) => {
    let empty = false;
    let data = client.ZREVRANGE("search", 0, 9, function(err, result) {
        if (result.length == 0) {
            empty = true;
        }
        res.render('popSearch', {show: result, empty: empty})
        res.status(200);
    })
})

module.exports = router;