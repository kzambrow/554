const express = require('express');
const router = express.Router();
const movieDetails = require('../public/movies.json');

router.get('/', async (req, res) => {
    try {
        res.status(200).render('home', {movieCard: movieDetails});
    } catch (e) {
        res.status(500).json({error: e});
    }
});
module.exports = router;